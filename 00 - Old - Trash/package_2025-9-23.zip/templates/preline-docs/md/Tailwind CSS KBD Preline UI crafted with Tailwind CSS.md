---
title: "Tailwind CSS KBD Preline UI crafted with Tailwind CSS"
source_type: "pdf"
converted_at: "2025-09-23T05:59:11"
page_count: 3
ai_note: "Headings per page; bullets preserved; paragraphs merged; hyphenated wraps fixed."
---

## Page 1
Cont ent Tailwind CSS KBD The <kbd> HTML element represents a span of inline text denoting textual user input from a keyboard, voice input, or any other text entry device. The most commonly used kbd styles. Pr eview HTML Copy ctrlctrlctrl ctrl ctrl Examples with icons to create different types of keyboard input elements. Pr eview HTML Copy Examples with modifiers to create different types of keyboard input elements. Pr eview HTML Copy Types Working with icons Working with modifier ComponentsKBD Sidebar On this page v3.2.1 5,940

## Page 2
shiftandb KBD stacked small to large sizes. Pr eview HTML Copy ctrl ctrl ctrl Here's an input example with KBD. Pr eview HTML Copy List group example. Pr eview HTML Copy Bold Ctrl+ b It alic Ctrl+ i Underline Ctrl+ u Strikethrough Ctrl+ Alt+ u Sizes Input example Search or type a command List group example +/

## Page 3
Small text Ctrl+ s © 2025 Preline Labs.
