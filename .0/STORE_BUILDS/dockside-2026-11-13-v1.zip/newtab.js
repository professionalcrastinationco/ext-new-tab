// newtab.js - Dock UI for Quick Bookmarks
let currentData = null;

// Context menu icons (sized for menu)
const editIcon = `<span style="display:inline-flex;width:13px;height:13px;margin-right:7px">${ICON_PENCIL_SIMPLE}</span>`;
const deleteIcon = `<span style="display:inline-flex;width:13px;height:13px;margin-right:7px">${ICON_TRASH}</span>`;
const addIcon = `<span style="display:inline-flex;width:13px;height:13px;margin-right:7px">${ICON_PLUS}</span>`;

// Helper to render category icon (supports both emoji and Phosphor names)
function renderCategoryIcon(icon) {
    if (!icon) return CATEGORY_ICONS.folder || '📁';
    if (isCustomIcon(icon)) return customIconMarkup(icon) || CATEGORY_ICONS.globe;
    // Check if it's a Phosphor icon name (in CATEGORY_ICONS)
    if (CATEGORY_ICONS[icon]) {
        return CATEGORY_ICONS[icon];
    }
    // Otherwise treat as emoji/text
    return icon;
}

// Helper to render quick link icon
function renderQuickLinkIcon(iconName) {
    if (isCustomIcon(iconName)) return customIconMarkup(iconName) || CATEGORY_ICONS['globe'] || ICON_GLOBE;
    // Check QUICK_ACCESS_ICONS first, then fall back to CATEGORY_ICONS
    if (typeof QUICK_ACCESS_ICONS !== 'undefined' && QUICK_ACCESS_ICONS[iconName]) {
        return QUICK_ACCESS_ICONS[iconName];
    }
    if (CATEGORY_ICONS[iconName]) {
        return CATEGORY_ICONS[iconName];
    }
    // Fallback to globe
    return CATEGORY_ICONS['globe'] || ICON_GLOBE;
}

// Populate icon picker grid
function populateIconPicker(selectedIcon, updatePreview = true) {
    const picker = document.getElementById('icon-picker');
    const hiddenInput = document.getElementById('category-icon');
    const previewIcon = document.getElementById('category-preview-icon');

    // Set hidden input value
    hiddenInput.value = selectedIcon || 'briefcase';

    // Update preview icon
    if (updatePreview && previewIcon) {
        previewIcon.innerHTML = isCustomIcon(hiddenInput.value)
            ? (customIconMarkup(hiddenInput.value) || CATEGORY_ICONS['globe'])
            : (CATEGORY_ICONS[hiddenInput.value] || CATEGORY_ICONS['briefcase']);
    }
    syncCustomIconRow('category', hiddenInput.value);

    // Get category icons from icons.js
    const iconNames = Object.keys(CATEGORY_ICONS);

    picker.innerHTML = iconNames.map(name => `
        <button type="button"
                class="icon-picker-item${hiddenInput.value === name ? ' selected' : ''}"
                data-icon="${name}"
                title="${name.replace(/-/g, ' ')}">
            ${CATEGORY_ICONS[name]}
        </button>
    `).join('');

    // Click handler for icon selection
    picker.onclick = (e) => {
        const item = e.target.closest('.icon-picker-item');
        if (!item) return;

        // Update selection
        picker.querySelectorAll('.icon-picker-item').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        hiddenInput.value = item.dataset.icon;
        syncCustomIconRow('category', '');

        // Update preview icon in real-time
        if (previewIcon) {
            previewIcon.innerHTML = CATEGORY_ICONS[item.dataset.icon] || CATEGORY_ICONS['briefcase'];
        }
    };
}

// Populate quick link icon picker grid (includes both brand and category icons)
function populateQuickLinkIconPicker(selectedIcon, updatePreview = true) {
    const picker = document.getElementById('quick-link-icon-picker');
    const hiddenInput = document.getElementById('quick-link-icon');
    const previewIcon = document.getElementById('quick-link-preview-icon');
    if (!picker || !hiddenInput) return;

    hiddenInput.value = selectedIcon || 'globe';

    // Combine quick access icons and category icons
    const allIcons = {
        ...(typeof QUICK_ACCESS_ICONS !== 'undefined' ? QUICK_ACCESS_ICONS : {}),
        ...CATEGORY_ICONS
    };
    const iconNames = Object.keys(allIcons);

    // Update preview icon
    if (updatePreview && previewIcon) {
        previewIcon.innerHTML = isCustomIcon(hiddenInput.value)
            ? (customIconMarkup(hiddenInput.value) || allIcons['globe'])
            : (allIcons[hiddenInput.value] || allIcons['globe'] || CATEGORY_ICONS['globe']);
    }
    syncCustomIconRow('quick-link', hiddenInput.value);

    picker.innerHTML = iconNames.map(name => `
        <button type="button"
                class="icon-picker-item${hiddenInput.value === name ? ' selected' : ''}"
                data-icon="${name}"
                title="${name.replace(/-/g, ' ')}">
            ${allIcons[name]}
        </button>
    `).join('');

    picker.onclick = (e) => {
        const item = e.target.closest('.icon-picker-item');
        if (!item) return;

        picker.querySelectorAll('.icon-picker-item').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        hiddenInput.value = item.dataset.icon;
        syncCustomIconRow('quick-link', '');

        // Update preview icon in real-time
        if (previewIcon) {
            previewIcon.innerHTML = allIcons[item.dataset.icon] || allIcons['globe'] || CATEGORY_ICONS['globe'];
        }
    };

    // Search filter
    const search = document.getElementById('quick-link-icon-search');
    if (search) {
        search.value = '';
        search.oninput = () => {
            const q = search.value.trim().toLowerCase();
            picker.querySelectorAll('.icon-picker-item').forEach(el => {
                el.style.display = !q || el.dataset.icon.toLowerCase().includes(q) ? '' : 'none';
            });
        };
    }
}

// Drag to reorder. Items live-move inside the container while dragging and the
// new order is saved on drop. The plus button stays last. Listeners are added
// once per container and only act while one of its own items is being dragged.
let sortingItem = null;

function makeSortable(container, itemSelector, addSelector, onDone) {
    if (container.dataset.sortable) return;
    container.dataset.sortable = '1';

    container.addEventListener('dragstart', (e) => {
        const item = e.target.closest ? e.target.closest(itemSelector) : null;
        // Ignore drags that start on something inside an item (for example a bookmark link)
        if (!item || e.target !== item) return;
        sortingItem = item;
        container.classList.add('sorting');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', item.dataset.id || '');
        requestAnimationFrame(() => item.classList.add('dragging'));
    });

    container.addEventListener('dragover', (e) => {
        if (!sortingItem || !container.contains(sortingItem)) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        const rows = container.id === 'quickLinks'; // several rows: also compare vertical position
        const others = [...container.querySelectorAll(itemSelector)].filter(el => el !== sortingItem);
        const next = others.find(el => {
            const r = el.getBoundingClientRect();
            if (rows) {
                if (e.clientY < r.top) return true;
                if (e.clientY > r.bottom) return false;
            }
            return e.clientX < r.left + r.width / 2;
        });
        const end = container.querySelector(addSelector);
        const anchor = next || end || null;
        const parent = anchor ? anchor.parentNode : sortingItem.parentNode;
        if (anchor !== sortingItem.nextSibling || parent !== sortingItem.parentNode) parent.insertBefore(sortingItem, anchor);
    });

    container.addEventListener('drop', (e) => {
        if (sortingItem) e.preventDefault();
    });

    container.addEventListener('dragend', async () => {
        if (!sortingItem) return;
        const ids = [...container.querySelectorAll(itemSelector)].map(el => el.dataset.id);
        sortingItem.classList.remove('dragging');
        sortingItem = null;
        container.classList.remove('sorting');
        await onDone(ids);
    });
}

// Quick links: at most 10 per row and 2 rows (the plus button does not count)
const QUICK_LINKS_PER_ROW = 10;
const QUICK_LINK_LIMIT = 20;

// The search bar is at least 600px and grows with the quick links: 30px wider than
// the widest row on each side
const SEARCH_MIN_WIDTH = 600;
const SEARCH_SIDE_SPACE = 30;
function sizeSearchToQuickLinks() {
    let widest = 0;
    document.querySelectorAll('#quickLinks .quick-links-row').forEach(row => {
        widest = Math.max(widest, row.scrollWidth);
    });
    const width = Math.max(SEARCH_MIN_WIDTH, widest + 2 * SEARCH_SIDE_SPACE);
    document.documentElement.style.setProperty('--search-w', width + 'px');
}

// Render quick access links
function renderQuickLinks(quickLinks, openInNewTab) {
    const container = document.getElementById('quickLinks');
    if (!container) return;

    container.innerHTML = '';

    // Remove old context menu listener by cloning
    const newContainer = container.cloneNode(false);
    container.parentNode.replaceChild(newContainer, container);
    delete newContainer.dataset.sortable; // the clone copies attributes but not listeners

    // Add context menu to container for adding new links (must be added before populating)
    newContainer.addEventListener('contextmenu', (e) => {
        // Only show add menu if clicking on container itself or empty state
        if (e.target === newContainer || e.target.classList.contains('quick-links-empty')) {
            e.preventDefault();
            showContextMenu(e, [
                {
                    content: `${addIcon}Add Quick Link`,
                    events: {
                        click: () => showQuickLinkModal(null)
                    }
                }
            ], 'dark');
        }
    });

    // Plus button: always the last item, so adding is never hidden behind right-click
    const appendAddButton = (withHint, row) => {
        if (withHint) {
            const hint = document.createElement('span');
            hint.className = 'quick-links-empty';
            hint.textContent = 'No quick links. Click the plus to add.';
            row.appendChild(hint);
        }
        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.className = 'quick-link-add';
        addBtn.setAttribute('aria-label', 'Add Quick Link');
        addBtn.title = 'Add Quick Link';
        addBtn.innerHTML = ICON_PLUS;
        addBtn.addEventListener('click', () => showQuickLinkModal(null));
        row.appendChild(addBtn);
    };

    const newRow = () => {
        const row = document.createElement('div');
        row.className = 'quick-links-row';
        newContainer.appendChild(row);
        return row;
    };

    if (!quickLinks || quickLinks.length === 0) {
        appendAddButton(true, newRow());
        sizeSearchToQuickLinks();
        return;
    }

    // Sort by order, show at most 2 rows of 10
    const sortedLinks = [...quickLinks].sort((a, b) => a.order - b.order).slice(0, QUICK_LINK_LIMIT);
    let currentRow = null;

    sortedLinks.forEach((link, index) => {
        if (index % QUICK_LINKS_PER_ROW === 0) currentRow = newRow();
        const linkEl = document.createElement('a');
        linkEl.className = 'quick-link';
        linkEl.href = link.url;
        linkEl.dataset.id = link.id;
        linkEl.draggable = true;
        if (openInNewTab) {
            linkEl.target = '_blank';
            linkEl.rel = 'noopener noreferrer';
        }

        // Add context menu for edit/delete
        linkEl.addEventListener('contextmenu', (e) => {
            showContextMenu(e, [
                {
                    content: `${editIcon}Edit Quick Link`,
                    events: {
                        click: () => showQuickLinkModal(link)
                    }
                },
                {
                    content: `${deleteIcon}Delete Quick Link`,
                    divider: "top",
                    events: {
                        click: async () => {
                            const confirmed = await showConfirmDialog(`Delete "${link.title}"?`);
                            if (confirmed) {
                                await deleteQuickLink(link.id);
                                currentData = await loadData();
                                renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
                            }
                        }
                    }
                }
            ], 'dark');
        });

        const iconEl = document.createElement('div');
        iconEl.className = 'quick-link-icon';
        iconEl.innerHTML = renderQuickLinkIcon(link.icon);

        const titleEl = document.createElement('span');
        titleEl.className = 'quick-link-title';
        titleEl.textContent = link.title;

        linkEl.appendChild(iconEl);
        linkEl.appendChild(titleEl);
        currentRow.appendChild(linkEl);
    });

    // The plus button joins the last row and does not count toward the 10. Gone when full.
    if (sortedLinks.length < QUICK_LINK_LIMIT) appendAddButton(false, currentRow);
    sizeSearchToQuickLinks();

    makeSortable(newContainer, '.quick-link', '.quick-link-add', async (ids) => {
        await reorderQuickLinks(ids);
        currentData = await loadData();
        renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
    });
}

async function init() {
    // Set Phosphor icons
    document.getElementById('settingsIcon').innerHTML = ICON_GEAR;

    await loadCustomUploads();
    initCustomIconRow('quick-link', 'quick-link-icon', 'quick-link-preview-icon');
    initCustomIconRow('category', 'category-icon', 'category-preview-icon');
    currentData = await loadData();
    renderDock(currentData);
    renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
    loadSettings(currentData.settings);
    attachEventListeners();

    // New users (nothing saved yet) get the walkthrough once; others can replay it from Settings
    document.getElementById('tourBtn').addEventListener('click', () => window.DocksideTour.start());
    if (!currentData.settings.tourDone && currentData.categories.length === 0) window.DocksideTour.start();

    // Listen for storage updates
    window.addEventListener('storageUpdated', async (e) => {
        currentData = e.detail || await loadData();
        renderDock(currentData);
        renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
        loadSettings(currentData.settings);
    });
}

// Search engines the user can choose in Settings
const SEARCH_ENGINES = {
    google: { name: 'Google', url: 'https://www.google.com/search?q=' },
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=' },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' },
    brave: { name: 'Brave Search', url: 'https://search.brave.com/search?q=' },
    ecosia: { name: 'Ecosia', url: 'https://www.ecosia.org/search?q=' },
    yahoo: { name: 'Yahoo', url: 'https://search.yahoo.com/search?p=' },
    startpage: { name: 'Startpage', url: 'https://www.startpage.com/do/search?q=' }
};
let searchEngineKey = 'google';

function applySearchEngine(key) {
    searchEngineKey = SEARCH_ENGINES[key] ? key : 'google';
    document.getElementById('searchInput').placeholder = `Search ${SEARCH_ENGINES[searchEngineKey].name} or type a URL`;
}

function runSearch() {
    const query = document.getElementById('searchInput').value.trim();
    if (!query) return;
    if (query.includes('.') && !query.includes(' ')) {
        window.location.href = query.startsWith('http') ? query : `https://${query}`;
    } else {
        window.location.href = SEARCH_ENGINES[searchEngineKey].url + encodeURIComponent(query);
    }
}

function attachEventListeners() {
    initDockPanels();
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') runSearch(); });
    document.getElementById('searchBtn').addEventListener('click', runSearch);

    // Search engine choice
    const engineSelect = document.getElementById('searchEngineSelect');
    engineSelect.addEventListener('change', async (e) => {
        await updateSetting('searchEngine', e.target.value);
        applySearchEngine(e.target.value);
    });

    // Category modal handlers
    document.getElementById('close-category-modal').addEventListener('click', () => {
        document.getElementById('category-modal').close();
    });

    // Delete category button
    document.getElementById('delete-category-btn').addEventListener('click', async () => {
        const categoryId = document.getElementById('category-id').value;
        const category = currentData.categories.find(c => c.id === categoryId);
        if (!category) return;

        const hasLinks = category.links && category.links.length > 0;
        const message = hasLinks
            ? `Delete "${category.name}" and all ${category.links.length} bookmark(s)?`
            : `Delete "${category.name}"?`;

        const confirmed = await showConfirmDialog(message);
        if (confirmed) {
            await deleteCategory(categoryId);
            document.getElementById('category-modal').close();
            currentData = await loadData();
            renderDock(currentData);
        }
    });

    document.getElementById('category-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const name = formData.get('name').trim();
        const icon = formData.get('icon')?.trim() || null;
        const categoryId = formData.get('categoryId');

        if (!name) return;

        if (categoryId) {
            await updateCategory(categoryId, { name, ...(icon && { icon }) });
        } else {
            await createCategory(name, icon);
        }
        document.getElementById('category-modal').close();
        currentData = await loadData();
        renderDock(currentData);
    });

    // Link modal handlers
    document.getElementById('close-link-modal').addEventListener('click', () => {
        document.getElementById('link-modal').close();
    });

    // Delete link button
    document.getElementById('delete-link-btn').addEventListener('click', async () => {
        const linkId = document.getElementById('link-id').value;
        const categoryId = document.getElementById('link-original-category').value;
        const linkTitle = document.getElementById('link-title').value;

        const confirmed = await showConfirmDialog(`Delete "${linkTitle}"?`);
        if (confirmed) {
            await deleteLink(categoryId, linkId);
            document.getElementById('link-modal').close();
            currentData = await loadData();
            renderDock(currentData);
        }
    });

    document.getElementById('link-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const url = formData.get('url').trim();
        const title = formData.get('title').trim();
        const categoryId = formData.get('category');
        const linkId = formData.get('linkId');
        const originalCategory = formData.get('originalCategory');
        const addAsQuickLink = formData.get('addQuickLink') === 'on';

        if (!url || !title || !categoryId || !linkId) return;

        if (originalCategory !== categoryId) {
            // Move to different category
            await moveLink(linkId, originalCategory, categoryId);
            await updateLink(categoryId, linkId, { title, url });
        } else {
            // Update in same category
            await updateLink(categoryId, linkId, { title, url });
        }

        // Also add as quick link if checkbox was checked
        if (addAsQuickLink) {
            await addQuickLink({ title, url, icon: 'globe' });
        }

        document.getElementById('link-modal').close();
        currentData = await loadData();
        renderDock(currentData);
        renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
    });

    // Settings button
    const settingsModal = document.getElementById('settings-modal');
    document.getElementById('settingsBtn').addEventListener('click', () => {
        settingsModal.showModal();
    });

    // Close settings
    document.getElementById('close-settings-modal').addEventListener('click', () => {
        settingsModal.close();
    });

    // Click outside modal to close (backdrop click)
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.close();
        }
    });

    // Dock position change
    document.getElementById('dockPositionSelect').addEventListener('change', async (e) => {
        await updateSetting('dockPosition', e.target.value);
        currentData = await loadData();
        renderDock(currentData);
    });

    // Background change
    document.getElementById('backgroundSelect').addEventListener('change', async (e) => {
        await updateSetting('background', e.target.value);
        applyBackground(e.target.value);
    });

    // Open in new tab change
    document.getElementById('openInNewTabSelect').addEventListener('change', async (e) => {
        await updateSetting('openInNewTab', e.target.value === 'true');
        currentData = await loadData();
        renderDock(currentData);
    });

    // Manage categories button
    document.getElementById('manageCategoriesBtn').addEventListener('click', () => {
        // Open the old management interface
        window.location.href = 'manage.html';
    });

    // Quick link modal handlers
    document.getElementById('close-quick-link-modal').addEventListener('click', () => {
        document.getElementById('quick-link-modal').close();
    });

    // Delete quick link button
    document.getElementById('delete-quick-link-btn').addEventListener('click', async () => {
        const linkId = document.getElementById('quick-link-id').value;
        const linkTitle = document.getElementById('quick-link-title').value;

        if (!linkId) return;

        const confirmed = await showConfirmDialog(`Delete "${linkTitle}"?`);
        if (confirmed) {
            await deleteQuickLink(linkId);
            document.getElementById('quick-link-modal').close();
            currentData = await loadData();
            renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
        }
    });

    document.getElementById('quick-link-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const title = formData.get('title').trim();
        const url = formData.get('url').trim();
        const icon = formData.get('icon')?.trim() || 'globe';
        const linkId = formData.get('linkId');

        if (!title || !url) return;

        if (linkId) {
            // Update existing
            await updateQuickLink(linkId, { title, url, icon });
        } else {
            // Add new
            await addQuickLink({ title, url, icon });
        }

        document.getElementById('quick-link-modal').close();
        currentData = await loadData();
        renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
    });
}

function applyBackground(name) {
    const nightSky = name === 'night-sky';
    document.body.classList.toggle('bg-night-sky', nightSky);
    if (window.NightSky) nightSky ? window.NightSky.start() : window.NightSky.stop();
}

function loadSettings(settings) {
    const engineSelect = document.getElementById('searchEngineSelect');
    if (!engineSelect.options.length) {
        Object.entries(SEARCH_ENGINES).forEach(([key, engine]) => {
            const opt = document.createElement('option');
            opt.value = key;
            opt.textContent = engine.name;
            engineSelect.appendChild(opt);
        });
    }
    document.getElementById('searchEngineSelect').value = SEARCH_ENGINES[settings.searchEngine] ? settings.searchEngine : 'google';
    applySearchEngine(settings.searchEngine);
    document.getElementById('backgroundSelect').value = settings.background || 'spotlight';
    applyBackground(settings.background || 'spotlight');
    document.getElementById('dockPositionSelect').value = settings.dockPosition || 'bottom';
    document.getElementById('openInNewTabSelect').value = settings.openInNewTab !== false ? 'true' : 'false';
}

function createBookmarkCard(category, openInNewTab) {
    const card = document.createElement('div');
    card.className = 'bookmark-card';

    const header = document.createElement('div');
    header.className = 'card-header';

    const headerIcon = document.createElement('span');
    headerIcon.className = 'card-header-icon';
    const headerIconContent = renderCategoryIcon(category.icon);
    if (headerIconContent.startsWith('<')) {
        headerIcon.innerHTML = headerIconContent;
    } else {
        headerIcon.textContent = headerIconContent;
    }

    const headerName = document.createElement('span');
    headerName.className = 'card-header-name';
    headerName.textContent = category.name;

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'icon-btn';
    editBtn.title = 'Edit Category';
    editBtn.setAttribute('aria-label', `Edit ${category.name}`);
    editBtn.innerHTML = ICON_PENCIL_SIMPLE;
    editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeDockPanels();
        showCategoryModal(category);
    });

    header.append(headerIcon, headerName, editBtn);

    const list = document.createElement('div');
    list.className = 'bookmark-list';

    if (category.links.length === 0) {
        const empty = document.createElement('span');
        empty.className = 'bookmark-list-empty';
        empty.textContent = 'No bookmarks yet. Right-click to add!';
        list.appendChild(empty);
    } else {
        const sortedLinks = [...category.links].sort((a, b) => a.order - b.order);
        sortedLinks.forEach(bookmark => {
            const link = document.createElement('a');
            link.className = 'bookmark-link';
            link.href = bookmark.url;
            if (openInNewTab) {
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
            }

            // Add context menu for bookmark actions
            link.addEventListener('contextmenu', (e) => {
                showContextMenu(e, [
                    {
                        content: `${editIcon}Edit Bookmark`,
                        events: {
                            click: () => showLinkModal(bookmark, category.id)
                        }
                    },
                    {
                        content: `${deleteIcon}Delete Bookmark`,
                        divider: "top",
                        events: {
                            click: async () => {
                                const confirmed = await showConfirmDialog(`Delete "${bookmark.title}"?`);
                                if (confirmed) {
                                    await deleteLink(category.id, bookmark.id);
                                    currentData = await loadData();
                                    renderDock(currentData);
                                }
                            }
                        }
                    }
                ], 'dark');
            });

            const favicon = document.createElement('img');
            favicon.className = 'bookmark-favicon';
            favicon.src = getFaviconUrl(bookmark.url);
            favicon.alt = '';

            const title = document.createElement('span');
            title.className = 'bookmark-title';
            title.textContent = bookmark.title;

            link.appendChild(favicon);
            link.appendChild(title);
            list.appendChild(link);
        });
    }

    card.appendChild(header);
    card.appendChild(list);

    return card;
}

// Close any dock category panel that was pinned open by a click
function closeDockPanels() {
    document.querySelectorAll('.dock-icon.open').forEach(el => {
        el.classList.remove('open');
        const btn = el.querySelector('.dock-btn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
    });
}

// Dock icon click toggles its panel; clicking elsewhere or Escape closes it.
// Hovering an icon also opens the panel after a short pause (CSS only).
function initDockPanels() {
    const dock = document.getElementById('dock');
    dock.addEventListener('click', (e) => {
        const btn = e.target.closest('.dock-btn');
        if (!btn) return;
        const icon = btn.parentElement;
        const wasOpen = icon.classList.contains('open');
        closeDockPanels();
        if (!wasOpen) {
            icon.classList.add('open');
            btn.setAttribute('aria-expanded', 'true');
        }
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.dock-icon')) closeDockPanels();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeDockPanels();
    });
}

function renderDock(data) {
    const dockElement = document.getElementById('dock');
    const dockPosition = data.settings.dockPosition || 'bottom';
    const openInNewTab = data.settings.openInNewTab !== false;
    const hasCategories = data.categories && data.categories.length > 0;

    // Update dock position class
    dockElement.className = `dock dock-${dockPosition}`;

    // Clear dock
    dockElement.innerHTML = '';

    // Right-click on the dock background also offers Add Category (bound once)
    if (!dockElement.dataset.addMenu) {
        dockElement.dataset.addMenu = '1';
        dockElement.addEventListener('contextmenu', (e) => {
            if (e.target.closest('.dock-icon')) return;
            e.preventDefault();
            showContextMenu(e, [
                {
                    content: `${addIcon}Add Category`,
                    events: { click: () => showCategoryModal(null) }
                }
            ], 'dark');
        });
    }

    // Sort categories by order
    const sortedCategories = hasCategories ? [...data.categories].sort((a, b) => a.order - b.order) : [];

    if (!hasCategories) {
        const hint = document.createElement('span');
        hint.className = 'dock-empty-hint';
        hint.textContent = 'No categories yet. Click the plus to add a category.';
        dockElement.appendChild(hint);
    }

    sortedCategories.forEach(category => {
        const dockIcon = document.createElement('div');
        dockIcon.className = 'dock-icon';
        dockIcon.dataset.id = category.id;
        dockIcon.draggable = true;

        const dockBtn = document.createElement('button');
        dockBtn.type = 'button';
        dockBtn.className = 'dock-btn';
        dockBtn.setAttribute('aria-label', category.name);
        dockBtn.setAttribute('aria-haspopup', 'true');
        dockBtn.setAttribute('aria-expanded', 'false');

        const iconCircle = document.createElement('div');
        iconCircle.className = 'icon-circle';
        const iconContent = renderCategoryIcon(category.icon);
        // Check if it's an SVG (Phosphor) or text (emoji)
        if (iconContent.startsWith('<')) {
            iconCircle.innerHTML = iconContent;
        } else {
            iconCircle.textContent = iconContent;
        }
        dockBtn.appendChild(iconCircle);

        // Add context menu to icon for category actions
        dockBtn.addEventListener('contextmenu', (e) => {
            showContextMenu(e, [
                {
                    content: `${editIcon}Edit Category`,
                    events: {
                        click: () => showCategoryModal(category)
                    }
                },
                {
                    content: `${deleteIcon}Delete Category`,
                    divider: "top",
                    events: {
                        click: async () => {
                            const hasLinks = category.links && category.links.length > 0;
                            const message = hasLinks
                                ? `Delete "${category.name}" and all ${category.links.length} bookmark(s)?`
                                : `Delete "${category.name}"?`;

                            const confirmed = await showConfirmDialog(message);
                            if (confirmed) {
                                await deleteCategory(category.id);
                                currentData = await loadData();
                                renderDock(currentData);
                            }
                        }
                    }
                }
            ], 'dark');
        });

        // Name tooltip shown on hover or keyboard focus
        const tip = document.createElement('span');
        tip.className = 'tip';
        tip.textContent = category.name;

        const card = createBookmarkCard(category, openInNewTab);

        dockIcon.appendChild(dockBtn);
        dockIcon.appendChild(tip);
        dockIcon.appendChild(card);
        dockElement.appendChild(dockIcon);
    });

    // Plus button: always the last item in the dock
    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'dock-add';
    addBtn.setAttribute('aria-label', 'Add Category');
    addBtn.title = 'Add Category';
    addBtn.innerHTML = ICON_PLUS;
    addBtn.addEventListener('click', () => showCategoryModal(null));
    dockElement.appendChild(addBtn);

    makeSortable(dockElement, '.dock-icon', '.dock-add', async (ids) => {
        await reorderCategories(ids);
        currentData = await loadData();
        renderDock(currentData);
    });
}

function showCategoryModal(category = null) {
    const modal = document.getElementById('category-modal');
    const nameInput = document.getElementById('category-name');
    const idInput = document.getElementById('category-id');
    const previewTitle = document.getElementById('category-preview-title');
    const deleteBtn = document.getElementById('delete-category-btn');

    // category is null when adding a new one
    nameInput.value = category ? category.name : '';
    idInput.value = category ? category.id : '';

    // Populate preview header
    if (previewTitle) {
        previewTitle.textContent = (category && category.name) || (category ? 'Category' : 'New Category');
    }

    // Delete button only when editing an existing category
    if (deleteBtn) {
        deleteBtn.style.display = category ? 'flex' : 'none';
    }

    // Populate icon picker with current selection (also updates preview icon)
    populateIconPicker(category ? category.icon : null);

    modal.showModal();
    nameInput.focus();
}

function showLinkModal(link, categoryId) {
    const modal = document.getElementById('link-modal');
    const urlInput = document.getElementById('link-url');
    const titleInput = document.getElementById('link-title');
    const categorySelect = document.getElementById('link-category');
    const linkIdInput = document.getElementById('link-id');
    const originalCategoryInput = document.getElementById('link-original-category');
    const previewTitle = document.getElementById('link-preview-title');
    const previewImg = document.getElementById('link-preview-img');
    const deleteBtn = document.getElementById('delete-link-btn');

    // Populate category dropdown
    categorySelect.innerHTML = currentData.categories
        .sort((a, b) => a.order - b.order)
        .map(cat => `<option value="${cat.id}" ${cat.id === categoryId ? 'selected' : ''}>${escapeHtml(cat.name)}</option>`)
        .join('');

    urlInput.value = link.url;
    titleInput.value = link.title;
    linkIdInput.value = link.id;
    originalCategoryInput.value = categoryId;

    // Populate preview header
    if (previewTitle) {
        previewTitle.textContent = link.title || 'Bookmark';
    }
    if (previewImg) {
        previewImg.src = getFaviconUrl(link.url);
        previewImg.alt = link.title || '';
    }

    // Show delete button (editing existing bookmark)
    if (deleteBtn) {
        deleteBtn.style.display = 'flex';
    }

    // Reset checkbox (unchecked by default)
    const addQuickLinkCheckbox = document.getElementById('link-add-quick-link');
    if (addQuickLinkCheckbox) {
        addQuickLinkCheckbox.checked = false;
    }

    modal.showModal();
    titleInput.focus();
}

// Show quick link edit modal
// Popular links panel (right column of the Add Quick Link dialog)
function linkHost(url) {
    try {
        return new URL(url).hostname.replace(/^www\./, '').toLowerCase();
    } catch (e) {
        return '';
    }
}

function findQuickLinkByUrl(url) {
    const host = linkHost(url);
    return (currentData.quickLinks || []).find(l => linkHost(l.url) === host);
}

function renderPopularLinks() {
    const groups = document.getElementById('popular-groups');
    if (!groups || typeof POPULAR_LINKS === 'undefined') return;

    groups.innerHTML = '';
    POPULAR_LINKS.forEach(group => {
        const section = document.createElement('div');
        section.className = 'popular-group';

        const label = document.createElement('div');
        label.className = 'popular-group-label';
        label.textContent = group.name;
        section.appendChild(label);

        const tiles = document.createElement('div');
        tiles.className = 'popular-tiles';
        group.items.forEach(item => {
            const tile = document.createElement('button');
            tile.type = 'button';
            tile.className = 'popular-tile';
            tile.dataset.url = item.url;
            tile.setAttribute('aria-label', item.title);
            tile.innerHTML = `${renderQuickLinkIcon(item.icon)}<span class="popular-name">${item.title}</span>`;
            tile.classList.toggle('added', !!findQuickLinkByUrl(item.url));
            tile.setAttribute('aria-pressed', tile.classList.contains('added') ? 'true' : 'false');
            if (!tile.classList.contains('added') && currentData.quickLinks.length >= QUICK_LINK_LIMIT) {
                tile.classList.add('full');
                tile.title = 'Quick links are full (20 is the most)';
            }
            tile.addEventListener('click', async () => {
                const existing = findQuickLinkByUrl(item.url);
                if (existing) {
                    await deleteQuickLink(existing.id);
                } else if (currentData.quickLinks.length >= QUICK_LINK_LIMIT) {
                    return;
                } else {
                    await addQuickLink({ title: item.title, url: item.url, icon: item.icon });
                }
                currentData = await loadData();
                renderQuickLinks(currentData.quickLinks, currentData.settings.openInNewTab !== false);
                renderPopularLinks();
            });
            tiles.appendChild(tile);
        });
        section.appendChild(tiles);
        groups.appendChild(section);
    });
}

function showQuickLinkModal(link = null) {
    if (!link && currentData && currentData.quickLinks.length >= QUICK_LINK_LIMIT) {
        window.alert('Quick links are full. You can have up to 20 (two rows of ten). Delete one to add another.');
        return;
    }
    const modal = document.getElementById('quick-link-modal');
    // Popular links only when adding; editing keeps the single-column dialog
    modal.classList.toggle('ql-edit', !!link);
    if (!link) renderPopularLinks();
    const titleInput = document.getElementById('quick-link-title');
    const urlInput = document.getElementById('quick-link-url');
    const linkIdInput = document.getElementById('quick-link-id');
    const previewLabel = document.getElementById('quick-link-preview-label');
    const previewTitle = document.getElementById('quick-link-preview-title');
    const deleteBtn = document.getElementById('delete-quick-link-btn');

    if (link) {
        // Editing existing link
        if (previewLabel) previewLabel.textContent = 'Quick Link';
        if (previewTitle) previewTitle.textContent = link.title || 'Quick Link';
        titleInput.value = link.title;
        urlInput.value = link.url;
        linkIdInput.value = link.id;
        populateQuickLinkIconPicker(link.icon);

        // Show delete button
        if (deleteBtn) deleteBtn.style.display = 'flex';
    } else {
        // Adding new link
        if (previewLabel) previewLabel.textContent = 'Quick Link';
        if (previewTitle) previewTitle.textContent = 'New Quick Link';
        titleInput.value = '';
        urlInput.value = '';
        linkIdInput.value = '';
        populateQuickLinkIconPicker('globe');

        // Hide delete button
        if (deleteBtn) deleteBtn.style.display = 'none';
    }

    modal.showModal();
    titleInput.focus();
}

// Show confirm dialog (replaces native confirm())
function showConfirmDialog(message) {
    return new Promise((resolve) => {
        const modal = document.getElementById('confirm-modal');
        const messageEl = document.getElementById('confirm-message');
        const confirmBtn = document.getElementById('confirm-delete-btn');
        const cancelBtn = document.getElementById('cancel-confirm-btn');

        messageEl.textContent = message;

        const handleConfirm = () => {
            cleanup();
            resolve(true);
        };

        const handleCancel = () => {
            cleanup();
            resolve(false);
        };

        const cleanup = () => {
            confirmBtn.removeEventListener('click', handleConfirm);
            cancelBtn.removeEventListener('click', handleCancel);
            modal.close();
        };

        confirmBtn.addEventListener('click', handleConfirm);
        cancelBtn.addEventListener('click', handleCancel);

        modal.showModal();
    });
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
